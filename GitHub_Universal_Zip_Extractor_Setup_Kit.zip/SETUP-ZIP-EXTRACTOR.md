# ZIP extraction setup for GitHub

This is a **repository importer**. It is not a web unzip service. It imports each archive's files directly into the GitHub repository without creating a new folder named after the ZIP.

## What it does

- Accepts **any ZIP filename** with a `.zip` or `.ZIP` extension, including spaces.
- Preserves folders and filenames **inside** an archive.
- Recognises an extra export wrapper such as `business-ai-mastery/README.md` and removes the wrapper.
- Preserves an actual content folder like `assets/` or `docs/` instead of flattening its files.
- Skips files already present with exactly identical bytes.
- Replaces changed files **at the same relative path**, if you choose `--on-conflict replace`.
- Does not create names such as `photo (2).png`, duplicate `repo/repo/` folders or repeated extraction directories.
- Checks ZIP checksums and blocks directory traversal, symlinks and writes into protected repository configuration directories.
- Works offline, using only Python 3.10+ standard library.

## Option A: publish the course using GitHub's website (recommended)

This method avoids GitHub's **100 files per browser upload** limit. You only upload seven setup files, then one ZIP file.

1. Create a new public GitHub repository, for example `business-ai-mastery`.
2. Download and **extract the separate setup kit** on your computer. Upload its contents into your new repository root, preserving these paths exactly: `.github/workflows/extract-zips.yml`, `tools/extract_zips.py`, `tests/test_extract_zips.py`, `uploads/README.md`, `.gitignore`, `.gitattributes` and `SETUP-ZIP-EXTRACTOR.md`. Commit the setup.
3. Verify that `.github/workflows/extract-zips.yml` is visible in your repository. A hidden `.github` folder must not be omitted by your file manager.
4. Go to **Settings → Actions → General → Workflow permissions**. Verify that the workflow is allowed to use write access. The YAML requests `contents: write`, but organisational settings or branch rules may still block writes.
5. Navigate to your repo's **`uploads/`** folder. Select **Add file → Upload files**. Upload your existing course ZIP file, with **any filename**, and commit it.
6. Check **Actions → Extract uploaded ZIP archives**. The workflow runs tests, unpacks the ZIP into the repo root, skips identical files, replaces changed files in place, removes the uploaded ZIP from the latest commit, and commits the extracted content.
7. Open `README.md` at the repository root and browse the course. All pictures and lessons should be at their original relative paths.

The ZIP must be uploaded **inside `uploads/`**, not directly at the repo root. The extraction workflow must be installed before uploading it. No manual renaming of the ZIP is needed.

GitHub's web uploader currently allows at most 100 files in one batch and files up to 25 MiB each. Uploading the original course **as one ZIP** avoids the file count limit. A ZIP committed via the web and later deleted still remains in the repository's Git history.

## Option B: start with the combined ready-to-upload repository

If you prefer GitHub Desktop or Git on your computer, you can use the supplied combined course and extractor ZIP. It already contains **all lessons, images, configuration and tests**, without an outer repository wrapper. Extract it on your computer and commit the entire folder to your GitHub repository. This is convenient with GitHub Desktop or command-line Git, which are not constrained by the browser's 100-file-at-once upload limit.

If a **branch protection rule** prevents automated pushes, run the extractor locally and open a normal pull request, or adjust branch rules according to your organisation's policies. Do not broadly weaken branch protection just to enable this importer.

## Option C: use locally whenever you want

From your repository root:

```bash
# Show what would happen; no files written
python tools/extract_zips.py "uploads/Any File Name.zip" --dest . --dry-run --on-conflict replace

# Import one ZIP, preserving its internal structure
python tools/extract_zips.py "uploads/Any File Name.zip" --dest . --on-conflict replace

# Import every ZIP in uploads/, regardless of filename
python tools/extract_zips.py --all --source uploads --dest . --on-conflict replace

# Delete processed ZIP uploads after successful imports
python tools/extract_zips.py --all --source uploads --dest . --on-conflict replace --delete-archives

# If an archive has an ambiguous outer wrapper: force removal
python tools/extract_zips.py "uploads/Ambiguous Package.zip" --strip-wrapper always --on-conflict replace

# Preserve even an obvious wrapper exactly as stored in ZIP
python tools/extract_zips.py "uploads/Keep All Paths.zip" --strip-wrapper never --on-conflict replace
```

The filename is **never hardcoded**. `--all` scans recursively for any file with a ZIP extension.

## Handling existing files

| Mode | Already exists with identical bytes | Already exists but differs |
| --- | --- | --- |
| `error` (safe CLI default) | Skip unchanged | Stop before changing the repository |
| `skip` | Skip unchanged | Leave old content in place |
| `replace` (GitHub Actions mode) | Skip unchanged | Update same filename in place |

In `replace` mode, later archives in alphabetic pathname order take priority for paths shared across multiple ZIP files. To avoid accidental replacement, upload one archive at a time.

**Not a semantic deduplicator:** If two different paths contain the same photograph, both paths remain. Renaming a file also produces a new path. The tool prevents repeat extraction and duplicate filenames **at the same path**, but cannot safely guess which different filenames should be merged.

## How outer folder removal works

```
ZIP archive: Anything-at-all.zip
└── business-ai-mastery/
    ├── README.md
    ├── 01-foundations/
    └── assets/

After import (to repository root):
README.md
01-foundations/
assets/
```

A single `docs/guide.md` or `assets/photo.webp` folder is **preserved**. If an export has no recognisable root document and its outer folder is ambiguous, use `--strip-wrapper always` after checking a `--dry-run`. A project archive with several top-level folders is extracted as-is. This avoids destroying meaningful directory structures.

## Safety and limits

- Uploaded ZIP paths cannot escape the destination with `../`, absolute paths or Windows drive letters.
- ZIP entries that are symlinks or special files are blocked.
- `.github/`, `.git/`, `tools/` and `uploads/` cannot be overwritten from an archive by default. For trusted manual imports only, `--allow-config-files` explicitly disables that protection.
- The default limits are 20,000 files, 500 MiB total extracted size and 100 MiB per file; adjust via command flags when appropriate. GitHub has separate per-file and upload restrictions.
- The workflow runs on pushes to `uploads/`; do not expose your repository write permissions to untrusted ZIP submissions.
- Default command-line mode errors on changed files. GitHub Actions uses `replace` for intentional course updates.
- The extractor validates and stages the archive before writing, but it is **not a transactional backup system**. Use Git history to review and roll back changes.
- GitHub Actions needs permission to push to the chosen branch. A protected branch may require a pull request instead.

## Verify locally

```bash
python -m unittest discover -s tests -v
python tools/extract_zips.py --help
```

## Troubleshooting

**Nothing happened:** Confirm the workflow is on GitHub already, the archive was committed to `uploads/`, and check the Actions tab. You can also run it manually with **Run workflow**.

**Permission denied:** Check Settings → Actions → General and repository branch rules. Some organisation policies override the YAML permission request.

**Conflict error locally:** Your current file differs from the ZIP. Review first with `--dry-run`, then deliberately select `--on-conflict replace` if updating is intended.

**Archive still has an extra wrapper:** It may not contain an obvious project root marker. Inspect the ZIP and try `--strip-wrapper always`; use it only if the entire outer folder is redundant.

**ZIP removed from the current branch but repository still large:** Older Git history retains the blob. For large archives, extract locally and push only the extracted files.

## Official GitHub documentation

- [GitHub Actions syntax and `paths` filters](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax)
- [Workflow permissions](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository)
- [Triggering GitHub Actions](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/trigger-a-workflow)
