# ZIP upload inbox

Upload any archive ending in `.zip` (capital `.ZIP` also works) to this folder.
A GitHub Actions workflow imports its contents into the **repository root**.

Examples of accepted filenames:

- `Business_AI_Mastery_Expanded_Public_GitHub_Course_Nov_2026.zip`
- `new-lessons.zip`
- `Graphics Package v3.zip`

The workflow deliberately removes a recognized outer project wrapper, preserves the meaningful folders inside it, skips files with identical content, updates changed files in place, and deletes the processed ZIP upload. It does not make duplicate names such as `README (1).md`.

**Important:** Add ZIPs to this folder one at a time if you need to control which version wins. The workflow will refuse unsafe archive paths, symbolic links, or attempts to overwrite `.github/`, `tools/` and other extractor configuration files. Do not upload archives containing secrets or customer information to a public repository.

See [setup instructions](../SETUP-ZIP-EXTRACTOR.md).
